"""
Crypto Drop Alert Bot
Memantau semua koin di Binance dan kirim notifikasi Telegram
jika ada koin yang turun >= 10% dalam 30-60 menit.
"""

import os
import json
import time
import logging
import asyncio
import aiohttp
from datetime import datetime, timedelta
from collections import defaultdict, deque

# ─── KONFIGURASI ────────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "ISI_TOKEN_BOT_KAMU")
TELEGRAM_CHAT_ID   = os.environ.get("TELEGRAM_CHAT_ID",   "ISI_CHAT_ID_KAMU")

DROP_THRESHOLD_PCT  = 10.0   # Persen penurunan yang memicu alert
WINDOW_MINUTES      = 60     # Jendela waktu pemantauan (menit)
CHECK_INTERVAL_SEC  = 60     # Interval cek harga (detik)
COOLDOWN_MINUTES    = 60     # Jeda antar alert untuk koin yang sama (menit)

BINANCE_TICKER_URL  = "https://api.binance.com/api/v3/ticker/price"
BINANCE_24H_URL     = "https://api.binance.com/api/v3/ticker/24hr"
# ─────────────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
log = logging.getLogger(__name__)

# price_history[symbol] = deque of (timestamp, price)
price_history: dict[str, deque] = defaultdict(lambda: deque(maxlen=120))

# last_alert[symbol] = datetime of last alert sent
last_alert: dict[str, datetime] = {}


async def send_telegram(session: aiohttp.ClientSession, message: str):
    """Kirim pesan ke Telegram."""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    try:
        async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            if resp.status != 200:
                body = await resp.text()
                log.error(f"Telegram error {resp.status}: {body}")
    except Exception as e:
        log.error(f"Gagal kirim Telegram: {e}")


async def fetch_all_prices(session: aiohttp.ClientSession) -> dict[str, float]:
    """Ambil harga semua pasangan USDT dari Binance."""
    try:
        async with session.get(BINANCE_TICKER_URL, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            data = await resp.json()
        return {
            item["symbol"]: float(item["price"])
            for item in data
            if item["symbol"].endswith("USDT")
        }
    except Exception as e:
        log.error(f"Gagal fetch harga: {e}")
        return {}


def check_drops(now: datetime) -> list[dict]:
    """
    Cek semua koin: apakah ada yang turun >= DROP_THRESHOLD_PCT
    dibanding harga tertua dalam WINDOW_MINUTES terakhir.
    """
    alerts = []
    cutoff = now - timedelta(minutes=WINDOW_MINUTES)

    for symbol, history in price_history.items():
        # Filter hanya data dalam window waktu
        window = [(ts, px) for ts, px in history if ts >= cutoff]
        if len(window) < 2:
            continue

        oldest_ts, oldest_price = window[0]
        _, current_price = window[-1]

        if oldest_price <= 0:
            continue

        change_pct = ((current_price - oldest_price) / oldest_price) * 100

        if change_pct <= -DROP_THRESHOLD_PCT:
            # Cek cooldown
            last = last_alert.get(symbol)
            if last and (now - last) < timedelta(minutes=COOLDOWN_MINUTES):
                continue  # Masih dalam cooldown, skip

            elapsed_min = int((now - oldest_ts).total_seconds() / 60)
            alerts.append({
                "symbol": symbol,
                "oldest_price": oldest_price,
                "current_price": current_price,
                "change_pct": change_pct,
                "elapsed_min": elapsed_min,
            })

    return alerts


def format_alert(alert: dict) -> str:
    """Format pesan alert untuk Telegram."""
    symbol   = alert["symbol"].replace("USDT", "/USDT")
    old_px   = alert["oldest_price"]
    cur_px   = alert["current_price"]
    chg      = alert["change_pct"]
    elapsed  = alert["elapsed_min"]
    now_str  = datetime.now().strftime("%H:%M:%S")

    return (
        f"🔴 <b>CRYPTO DROP ALERT</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🪙 <b>{symbol}</b>\n"
        f"📉 Turun: <b>{chg:.2f}%</b> dalam {elapsed} menit\n"
        f"💰 Harga awal : ${old_px:.6g}\n"
        f"💸 Harga skrg : ${cur_px:.6g}\n"
        f"🕐 Waktu      : {now_str}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"⚠️ Bukan saran investasi!"
    )


async def main_loop():
    log.info("🚀 Bot dimulai — memantau semua koin USDT di Binance")
    log.info(f"   Threshold : turun >= {DROP_THRESHOLD_PCT}% dalam {WINDOW_MINUTES} menit")
    log.info(f"   Interval  : cek tiap {CHECK_INTERVAL_SEC} detik")

    async with aiohttp.ClientSession() as session:
        # Kirim pesan startup
        await send_telegram(session,
            f"✅ <b>Crypto Alert Bot Aktif!</b>\n"
            f"Memantau semua koin USDT di Binance.\n"
            f"Alert jika turun ≥ {DROP_THRESHOLD_PCT:.0f}% dalam {WINDOW_MINUTES} menit."
        )

        while True:
            now = datetime.now()
            prices = await fetch_all_prices(session)

            if prices:
                # Simpan snapshot harga saat ini
                for symbol, price in prices.items():
                    price_history[symbol].append((now, price))

                log.info(f"Snapshot: {len(prices)} koin diperbarui | {now.strftime('%H:%M:%S')}")

                # Cek penurunan
                drops = check_drops(now)
                if drops:
                    log.info(f"⚠️  {len(drops)} koin memenuhi threshold drop!")
                    for alert in drops:
                        msg = format_alert(alert)
                        await send_telegram(session, msg)
                        last_alert[alert["symbol"]] = now
                        log.info(f"Alert terkirim: {alert['symbol']} {alert['change_pct']:.2f}%")
                        await asyncio.sleep(0.3)  # Jeda antar pesan
            else:
                log.warning("Tidak ada data harga diterima, coba lagi...")

            await asyncio.sleep(CHECK_INTERVAL_SEC)


if __name__ == "__main__":
    asyncio.run(main_loop())
