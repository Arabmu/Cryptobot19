# 🤖 Crypto Drop Alert Bot

Bot Telegram yang memantau **semua koin USDT di Binance** dan mengirim notifikasi
jika ada koin yang **turun ≥ 10% dalam 60 menit**.

---

## ⚡ Cara Setup (5 Langkah)

### Langkah 1 — Buat Bot Telegram

1. Buka Telegram, cari **@BotFather**
2. Kirim perintah: `/newbot`
3. Ikuti instruksi, catat **TOKEN** yang diberikan
   - Contoh: `7123456789:AAHdqTcvCH1vGWJxfSeofSs0K38W8d0s`

### Langkah 2 — Dapatkan Chat ID kamu

1. Cari bot **@userinfobot** di Telegram
2. Kirim pesan apa saja, bot akan balas dengan **Chat ID** kamu
   - Contoh: `123456789`

### Langkah 3 — Deploy ke Railway (Gratis)

1. Daftar akun di https://railway.app (bisa pakai GitHub)
2. Klik **"New Project"** → **"Deploy from GitHub repo"**
3. Upload / push folder ini ke GitHub dulu, lalu pilih repo-nya
4. Setelah deploy, masuk ke tab **"Variables"** dan tambahkan:

   | Key                  | Value                        |
   |----------------------|------------------------------|
   | `TELEGRAM_BOT_TOKEN` | Token dari BotFather         |
   | `TELEGRAM_CHAT_ID`   | Chat ID kamu                 |

5. Railway akan otomatis menjalankan `Procfile` → `python bot.py`

> **Alternatif hosting gratis:** Render.com — proses sama, pilih "Background Worker"

### Langkah 4 — (Opsional) Jalankan Lokal

```bash
# Install dependencies
pip install -r requirements.txt

# Set variabel (Windows PowerShell)
$env:TELEGRAM_BOT_TOKEN = "token_kamu"
$env:TELEGRAM_CHAT_ID   = "chat_id_kamu"

# Set variabel (Mac/Linux)
export TELEGRAM_BOT_TOKEN="token_kamu"
export TELEGRAM_CHAT_ID="chat_id_kamu"

# Jalankan
python bot.py
```

---

## ⚙️ Pengaturan (di dalam bot.py)

| Variable             | Default | Keterangan                              |
|----------------------|---------|-----------------------------------------|
| `DROP_THRESHOLD_PCT` | `10.0`  | Persen penurunan yang memicu alert      |
| `WINDOW_MINUTES`     | `60`    | Jendela waktu pemantauan (menit)        |
| `CHECK_INTERVAL_SEC` | `60`    | Seberapa sering bot cek harga (detik)   |
| `COOLDOWN_MINUTES`   | `60`    | Jeda alert ulang untuk koin yang sama   |

---

## 📲 Contoh Notifikasi

```
🔴 CRYPTO DROP ALERT
━━━━━━━━━━━━━━━━━━━━
🪙 XYZ/USDT
📉 Turun: -12.45% dalam 47 menit
💰 Harga awal : $0.05821
💸 Harga skrg : $0.05096
🕐 Waktu      : 14:32:10
━━━━━━━━━━━━━━━━━━━━
⚠️ Bukan saran investasi!
```

---

## ❓ FAQ

**Q: Apakah perlu API key Binance?**
A: Tidak! Bot menggunakan endpoint publik Binance yang gratis tanpa autentikasi.

**Q: Berapa koin yang dipantau?**
A: Semua pasangan USDT di Binance — biasanya 300–400+ koin sekaligus.

**Q: Railway gratis sampai kapan?**
A: Railway memberikan $5 credit/bulan gratis. Bot ringan ini biasanya cukup 1 bulan penuh.
